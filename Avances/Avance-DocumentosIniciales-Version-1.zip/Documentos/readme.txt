Colocar aqui los documentos de idea, conformaci�n de grupo y  propuesta de desarrollo con sus correpondientes versiones. Los nobres de los documentos deben ser asi:
ideaproyecto-Version-x.txt
conformaciondegrupo-Version-x.docx
propuestadedesarrollo-version-x.docx
 