Debe colocar los avances del proyecto en cada uno de los puntos de entrega. El archivo .zip contiene los documentos creados para presentar el informe:
Avance-x-Version-x.zip

 