Lugar en el que se colocan todos los archivos del proyecto desarrollado en el entorno de programaci�n seleccionado:

Los formatos de los archivos, dirtectorios y dem�s dependeran del tipo de ptoyecto seleccionado y del lenguaje de programaci�n escogido.

 