Debe colocar cada una de las etapas de la metodolog�a de desarrollo seleccionada, creando una carpeta por etapa, fase, pasos, tareas, etc. en un arbol de directorios jer�rquico que depende de la propia metodolog�a. En cada carpeta estaran los documentos con los artefactos o productos dise�ados y presentados en los documentos adecuados.

 