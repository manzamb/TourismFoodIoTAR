# TourismFoodIoTAR - Tourism food in Augmented Reality

IDEA

Aplicación Web que, a través de elementos publicitarios y estrategias de marketing, permita la curación y procesamiento del catálogo gastronómico que reside en el departamento del Cauca. Con el fin de darle accesibilidad tanto a los turistas como los residentes del departamento.

CARACTERÍSTICAS

1. Tecnologías de las Que se parte:

Tecnologías de desarrollo de servicos web como el framework asp.net core y los entornos de desarrollo para aplicaciones móviles en android, tales como Android Studio y el Android SDK

2. Interfaces a Desarrollar

Se pretenden desarrollar las siguientes interfaces:

- API Web que permita gestionar un backend para todas las instancias de nuestra aplicación móvil.
- Una interfaz cliente, representada en la aplicación móvil, por la cual el usuario podrá interactuar con el sistema.
- Se Realizará un estado del arte acerca de soluciones similares al problema planteado, entregando una comparación de precios y características.

3. Hardware a Desplegar o usar

- Para la realización de la aplicación móvil, se instalará Android Studio, además de la herramienta Git con el propósito de llevar un control de las versiones del proyecto y trabajo en equipo.
- Se debe contar con un celular de sistema operativo Android, que nos permita instalar la aplicación y ejecutarla desde allí.
- Se Investigará la posibilidad de ampliar las funcionalidades de la aplicación por medio del uso de chips NFC o Marcadores de realidad virtual que permitan diferenciar, aún más, nuestra aplicación en el mercado.

ESTUDIANTES

Santiago Alejandro Pérez Solarte sapa_29@unicauca.edu.co

Juan Sebastián juanmontano@unicauca.edu.co

Eduardo Prado eduardoprado@unicauca.edu.co

Paola Alexandra Pino Malez paolapino@unicauca.edu.co


CLIENTE Y TUTOR

Miguel Angel Niño Zambrano manzamb@unicauca.edu.co
